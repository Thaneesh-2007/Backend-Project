# a9f64065-2733-49d5-9cd7-d205c901149f-b79b16f1-5c47-4c0a-aaa0-561614f615a4
Repository for Teams Project code and project management
