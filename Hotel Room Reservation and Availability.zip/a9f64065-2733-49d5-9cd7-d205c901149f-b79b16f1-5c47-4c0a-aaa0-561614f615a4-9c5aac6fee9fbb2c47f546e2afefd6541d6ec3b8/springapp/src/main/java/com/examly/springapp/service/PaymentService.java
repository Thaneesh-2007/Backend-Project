package com.examly.springapp.service;

import com.examly.springapp.model.Payment;

public interface PaymentService {
    Payment savePayment(Payment payment);
}