package com.examly.springapp.service;

import com.examly.springapp.model.Booking;

public interface BookingService {
    Booking saveBooking(Booking booking);
}